﻿using Halite2.hlt;
using System.Collections.Generic;
using System.Linq;

namespace Halite2
{
    public class MyBot
    {
        private static List<Move> _moveList;
        private static GameMap _gameMap;
        private static Networking _networking;

        public static void Main(string[] args)
        {
            string name = args.Length > 0 ? args[0] : "Grasshopper1";

            _networking = new Networking();
            _gameMap = _networking.Initialize(name);

            _moveList = new List<Move>();
            for (; ; )
            {
                _moveList.Clear();
                _gameMap.UpdateMap(Networking.ReadLineIntoMetadata());

                var player = _gameMap.GetMyPlayer();
                var ships = player.GetShips().Values;
                var availableShips = ships.Where(ship => ship.GetDockingStatus() == Ship.DockingStatus.Undocked)
                    .ToList();

                var notOwnedPlanets = _gameMap.GetAllNotOwnedPlanets();
                var targetPlanets = notOwnedPlanets.ToList();

                for (int i = 0; i < notOwnedPlanets.Count; i++)
                {
                    if (!availableShips.Any())
                    {
                        break;
                    }
                    var planetShipDistances = new List<PlanetShipDistance>();

                    foreach (var targetPlanet in targetPlanets)
                    {
                        var bestDistanceTo = 1e9;
                        PlanetShipDistance bestPlanetShipDistance = null;

                        foreach (var availableShip in availableShips)
                        {
                            var distance = availableShip.GetDistanceTo(targetPlanet.GetCenterPosition()) -
                                           targetPlanet.GetRadius();
                            if (distance < bestDistanceTo)
                            {
                                bestPlanetShipDistance = new PlanetShipDistance
                                {
                                    Distance = distance,
                                    Planet = targetPlanet,
                                    Ship = availableShip
                                };
                                bestDistanceTo = distance;
                            }
                        }
                        planetShipDistances.Add(bestPlanetShipDistance);
                    }

                    var bestGlobalPlanetShipDistance = planetShipDistances.OrderBy(planetShipDistance => planetShipDistance.Distance).First();
                    MoveOrDockShipToPlanet(bestGlobalPlanetShipDistance);

                    targetPlanets.Remove(bestGlobalPlanetShipDistance.Planet);
                    availableShips.Remove(bestGlobalPlanetShipDistance.Ship);

                }
                Networking.SendMoves(_moveList);
            }
        }

        private static void MoveOrDockShipToPlanet(PlanetShipDistance bestPlanetShipDistance)
        {
            var ship = bestPlanetShipDistance.Ship;
            var planet = bestPlanetShipDistance.Planet;

            if (ship.CanDock(planet))
            {
                _moveList.Add(new DockMove(ship, planet));
                return;
            }

            ThrustMove newThrustMove = Navigation.NavigateShipToDock(_gameMap, ship, planet, Constants.MAX_SPEED);
            if (newThrustMove != null)
            {
                _moveList.Add(newThrustMove);
            }
        }
    }

    public class PlanetShipDistance
    {
        public Planet Planet { get; set; }
        public Ship Ship { get; set; }
        public double Distance { get; set; }
    }
}
